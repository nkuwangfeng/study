/*
 * @Description: imu laser fusion 任务管理， 放在类里使代码更清晰
 * @Author: abao
 * @Date: 2020-11-14
 */
#include "lidar_localization/mapping/fusion/imu_laser_fusion_flow.hpp"
#include "glog/logging.h"
#include "lidar_localization/global_defination/global_defination.h"

namespace lidar_localization {
ImuLaserFusionFlow::ImuLaserFusionFlow(ros::NodeHandle& nh, std::string imu_topic, std::string odom_topic) {
    imu_sub_ptr_ = std::make_shared<IMUSubscriber>(nh, imu_topic, 1000);
    laser_odom_sub_ptr_ = std::make_shared<OdometrySubscriber>(nh, odom_topic, 1000);
    gnss_pose_sub_ptr_ = std::make_shared<OdometrySubscriber>(nh, "/synced_gnss", 1000);

    fused_imu_pub_ptr_ = std::make_shared<OdometryPublisher>(nh, "/fused_imu", "/map", "/lidar", 100);
    fused_odom_pub_ptr_ = std::make_shared<OdometryPublisher>(nh, "/fused_odom", "/map", "/lidar", 100);
    raw_laser_odom_pub_ptr_ = std::make_shared<OdometryPublisher>(nh, "/raw_laser_odom", "/map", "/lidar", 100);

    imu_laser_fusion_ptr_ = std::make_shared<ImuLaserFusion>();
}

bool ImuLaserFusionFlow::Run() {
    if (!ReadData())
        return false;

    // while(HasData()) {
    //     if (!ValidData())
    //         continue;
    //     if (UpdateImuAndOdometry()) {
    //         PublishData();
    //     }
    // }

    WaitAndSetInitPose();
    if (HasData()) {
        UpdateImuAndOdometry();
        DropData();
    }

    return true;
}

bool ImuLaserFusionFlow::ReadData() {
    imu_sub_ptr_->ParseData(imu_data_buf_);
    laser_odom_sub_ptr_->ParseData(laser_odom_data_buff_);
    gnss_pose_sub_ptr_->ParseData(gnss_pose_data_buff_);
    return true;
}

bool ImuLaserFusionFlow::HasData() {
    return odometry_inited_ && imu_data_buf_.size() > 0;
}

bool ImuLaserFusionFlow::ValidData() {
    return true;
}

bool ImuLaserFusionFlow::UpdateImuAndOdometry() {
    if (!odometry_inited_)
        return false;

    if (imu_data_buf_.empty() && laser_odom_data_buff_.empty())
        return false;

    for (const IMUData& imu : imu_data_buf_) {
        imu_laser_fusion_ptr_->ProcessImu(imu);
        fused_imu_pub_ptr_->Publish(imu_laser_fusion_ptr_->GetPose(), imu.time);
    }
    if (!laser_odom_data_buff_.empty()) {
        PoseData pose_data = laser_odom_data_buff_.front();
        pose_data.pose = odom_init_pose_ * laser_odom_data_buff_.front().pose;
        imu_laser_fusion_ptr_->ProcessOdom(pose_data);
        fused_odom_pub_ptr_->Publish(imu_laser_fusion_ptr_->GetPose(), pose_data.time);
        raw_laser_odom_pub_ptr_->Publish(pose_data.pose, pose_data.time);
    }

    return true;
}

bool ImuLaserFusionFlow::PublishData() {
    //fused_odom_pub_ptr_->Publish(laser_odometry_, ros::Time::now().toSec());

    return true;
}

bool ImuLaserFusionFlow::DropData() {
    imu_data_buf_.clear();
    laser_odom_data_buff_.clear();
    gnss_pose_data_buff_.clear();
    return true;
}

bool ImuLaserFusionFlow::WaitAndSetInitPose() {
    if (!odometry_inited_ && !laser_odom_data_buff_.empty() && !gnss_pose_data_buff_.empty()) {
        odometry_inited_ = true;

        odom_init_pose_ = gnss_pose_data_buff_.back().pose * laser_odom_data_buff_.back().pose.inverse();

        imu_laser_fusion_ptr_->SetInitPose(gnss_pose_data_buff_.back().pose);

        DropData();
    }
}

}