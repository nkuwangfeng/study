/*
 * @Description: imu laser kalman filter
 * @Author: abao
 * @Date: 2020-11-14
 */
#include "lidar_localization/mapping/fusion/imu_laser_fusion.hpp"

#include <iostream>
#include <fstream>
#include <boost/filesystem.hpp>
#include "glog/logging.h"

#include "lidar_localization/global_defination/global_defination.h"

namespace lidar_localization {

constexpr double kDegreeToRadian = M_PI / 180.;
constexpr double kRadianToDegree = 180. / M_PI;

ImuLaserFusion::ImuLaserFusion() {
    acc_noise_ = 1e-2;
    gyro_noise_ = 1e-4;
    acc_bias_noise_ = 1e-6;
    gyro_bias_noise_ = 1e-8;
    laser_pose_noise_ = 0.1;
    laser_orient_noise_ = 5*kDegreeToRadian;
}

bool ImuLaserFusion::SetInitPose(const Eigen::Matrix4f& init_pose) {
    initialized_ = true;
    // set global P/v/R
    state_.G_P = Eigen::Vector3d(init_pose(0,3), init_pose(1,3), init_pose(2,3));
    state_.G_v.setZero();
    state_.G_R = init_pose.block<3, 3>(0, 0).cast<double>();
    // set bias
    state_.acc_bias.setZero();
    state_.gyro_bias.setZero();

    // Set covariance.
    state_.cov.setZero();
    state_.cov.block<3, 3>(0, 0) = 100. * Eigen::Matrix3d::Identity(); // position std: 10 m
    state_.cov.block<3, 3>(3, 3) = 100. * Eigen::Matrix3d::Identity(); // velocity std: 10 m/s
    // roll pitch std 10 degree.
    state_.cov.block<2, 2>(6, 6) = 10. * kDegreeToRadian * 10. * kDegreeToRadian * Eigen::Matrix2d::Identity();
    state_.cov(8, 8)             = 100. * kDegreeToRadian * 100. * kDegreeToRadian; // yaw std: 100 degree.
    // Acc bias.
    state_.cov.block<3, 3>(9, 9) = 0.0004 * Eigen::Matrix3d::Identity();
    // Gyro bias.
    state_.cov.block<3, 3>(12, 12) = 0.0004 * Eigen::Matrix3d::Identity();
    return true;
}

bool ImuLaserFusion::ProcessImu(const IMUData& imu) {
    if (!initialized_)
        return false;

    if (!has_last_imu_) {
        has_last_imu_ = true;
        last_imu_ = imu;
        return false;
    }

    const double delta_t = imu.time - last_imu_.time;
    const double delta_t2 = delta_t * delta_t;
    LOG(INFO) << "imu,diff=" << delta_t;
    if (delta_t <= 0.f) {
        std::cout << "time revert..\n";
        return false;
    }

    State last_state = state_;

    // Acc and gyro.
    const Eigen::Vector3d last_acc = Eigen::Vector3d(last_imu_.linear_acceleration.x, last_imu_.linear_acceleration.y, last_imu_.linear_acceleration.z);
    const Eigen::Vector3d curr_acc = Eigen::Vector3d(imu.linear_acceleration.x, imu.linear_acceleration.y, imu.linear_acceleration.z);
    const Eigen::Vector3d last_gyro = Eigen::Vector3d(last_imu_.angular_velocity.x, last_imu_.angular_velocity.y, last_imu_.angular_velocity.z);
    const Eigen::Vector3d curr_gyro = Eigen::Vector3d(imu.angular_velocity.x, imu.angular_velocity.y, imu.angular_velocity.z);
    const Eigen::Vector3d acc_unbias = 0.5 * (last_acc + curr_acc) - last_state.acc_bias;
    const Eigen::Vector3d gyro_unbias = 0.5 * (last_gyro + curr_gyro) - last_state.gyro_bias;

    // Normal state
    state_.G_P = last_state.G_P + last_state.G_v * delta_t + 
                   0.5 * (last_state.G_R * acc_unbias + gravity_) * delta_t2;
    state_.G_v = last_state.G_v + (last_state.G_R * acc_unbias + gravity_) * delta_t;
    const Eigen::Vector3d delta_angle_axis = gyro_unbias * delta_t;
    if (delta_angle_axis.norm() > 1e-12) {
        state_.G_R = last_state.G_R * Eigen::AngleAxisd(delta_angle_axis.norm(), delta_angle_axis.normalized()).toRotationMatrix();
    }

    // \dot X = F_tX + B_tW

    // F_{k-1} = I + F_tT
    const double omega = 7.292115e-5;
    const double L = 48.982530923568 * kDegreeToRadian;
    Eigen::Matrix<double, 15, 15> Ft = Eigen::Matrix<double, 15, 15>::Zero();
    Ft.block<3,3>(0,3) = Eigen::Matrix3d::Identity();
    Ft.block<3,3>(3,6) = -state_.G_R * GetSkewMatrix(acc_unbias); // F23
    Ft(6,7) = omega * sin(L);  // F33
    Ft(6,8) = -omega * cos(L);
    Ft(7,6) = -omega * sin(L);
    Ft(8,6) = omega * cos(L);
    Ft.block<3,3>(3,12) = state_.G_R;
    Ft.block<3,3>(6,9) = -state_.G_R;
    Eigen::Matrix<double, 15, 15> Fk_1 = Eigen::Matrix<double, 15, 15>::Identity() + Ft * delta_t;

    // B_{k-1} = B_tT
    Eigen::Matrix<double, 15, 6> Bt = Eigen::Matrix<double, 15, 6>::Zero();
    Bt.block<3,3>(3,3) = state_.G_R;
    Bt.block<3,3>(6,0) = -state_.G_R;
    Eigen::Matrix<double, 15, 6> Bk_1 = Bt * delta_t;

    Eigen::Matrix<double, 6, 6> Qk = Eigen::Matrix<double, 6, 6>::Zero();
    Qk.block<3, 3>(0, 0) = delta_t2 * gyro_noise_ * Eigen::Matrix3d::Identity();
    Qk.block<3, 3>(3, 3) = delta_t2 * acc_noise_ * Eigen::Matrix3d::Identity();

    // update P
    state_.cov = Fk_1 * last_state.cov * Fk_1.transpose() + Bk_1 * Qk * Bk_1.transpose();

    last_imu_ = imu;
    return true;
}

bool ImuLaserFusion::ProcessOdom(const PoseData& pose_data) {
    // observation
    // Yk = [dPx, dPy, dPz, dPhx, dPhy, dPhz]
    const Eigen::Matrix3d C_b_n_p = state_.G_R;
    const Eigen::Matrix3d C_b_n = pose_data.pose.cast<double>().block<3,3>(0,0);
    const Eigen::Matrix3d C_n_n = C_b_n_p * C_b_n.transpose();
    const Eigen::Matrix3d phi_x = Eigen::Matrix3d::Identity() - C_n_n;
    // C_n^n \approx I - \phi\times
    double phx = (phi_x(2,1) - phi_x(1,2)) / 2.;
    double phy = (phi_x(0,2) - phi_x(2,0)) / 2.;
    double phz = (phi_x(1,0) - phi_x(0,1)) / 2.;
    //LOG(INFO) << "phi=" << std::endl << phi_x << std::endl << "p=" << px << "," << py << "," << pz << std::endl;
    Eigen::Matrix<double, 6, 1> Yk;
    Yk.block<3,1>(0,0) = pose_data.pose.cast<double>().block<3,1>(0,3) - state_.G_P;
    Yk(3,0) = phx;
    Yk(4,0) = phy;
    Yk(5,0) = phz;

    // K_k = P_kG_k^T(G_kP_kG_k^T + C_KR_kC_k^T)^{-1}
    const Eigen::MatrixXd& Pk = state_.cov;
    Eigen::Matrix<double, 6, 15> Gk = Eigen::Matrix<double, 6, 15>::Zero();
    Gk.block<3,3>(0,0) = Gk.block<3,3>(3,6) = Eigen::Matrix3d::Identity();
    Eigen::Matrix<double, 6, 6> Ck = Eigen::Matrix<double, 6, 6>::Identity();
    Eigen::Matrix<double, 6, 6> Rk = Eigen::Matrix<double, 6, 6>::Identity();
    Rk.block<3,3>(0,0) *= laser_pose_noise_;
    Rk.block<3,3>(3,3) *= laser_orient_noise_;
    const Eigen::MatrixXd Kk = Pk * Gk.transpose() * (Gk * Pk * Gk.transpose() + Ck * Rk * Ck.transpose()).inverse();

    // \hat{P_k} = (I-K_kG_k)\check{P_k}
    state_.cov = (Eigen::Matrix<double, 15, 15>::Identity() - Kk * Gk) * Pk;

    // \hat{x_k} = \check{x_k} + K_k(Y_k-G_k\check{X_k})
    Eigen::Matrix<double, 15, 1> Xk = Eigen::Matrix<double, 15, 1>::Zero();
    const Eigen::VectorXd delta_x = Kk * (Yk - Gk*Xk);

    // \hat{x_k} = \check{x_k} + delta_x
    state_.G_P     += delta_x.block<3, 1>(0, 0);
    state_.G_v     += delta_x.block<3, 1>(3, 0);
    state_.acc_bias  += delta_x.block<3, 1>(9, 0);
    state_.gyro_bias += delta_x.block<3, 1>(12, 0);
    if (delta_x.block<3, 1>(6, 0).norm() > 1e-12) {
        state_.G_R *= Eigen::AngleAxisd(delta_x.block<3, 1>(6, 0).norm(), delta_x.block<3, 1>(6, 0).normalized()).toRotationMatrix();
    }

    return true;
}

Eigen::Matrix4f ImuLaserFusion::GetPose() {
    Eigen::Matrix4f pose;
    pose.block<3,3>(0,0) = state_.G_R.cast<float>();
    pose(0,3) = state_.G_P(0);
    pose(1,3) = state_.G_P(1);
    pose(2,3) = state_.G_P(2);
    return pose;
}

Eigen::Matrix3d ImuLaserFusion::GetSkewMatrix(const Eigen::Vector3d& v) {
    Eigen::Matrix3d w;
    w <<  0.,   -v(2),  v(1),
          v(2),  0.,   -v(0),
         -v(1),  v(0),  0.;

    return w;
}

}