/*
 * @Description: imu laser kalman filter
 * @Author: abao
 * @Date: 2020-11-14
 */
#ifndef LIDAR_LOCALIZATION_MAPPING_FUSION_IMU_LASER_FUSION_HPP_
#define LIDAR_LOCALIZATION_MAPPING_FUSION_IMU_LASER_FUSION_HPP_

#include <deque>
#include <Eigen/Dense>
#include <yaml-cpp/yaml.h>
#include "lidar_localization/sensor_data/imu_data.hpp"
#include "lidar_localization/sensor_data/pose_data.hpp"

namespace lidar_localization {

struct State {
    Eigen::Vector3d G_P;     // global pose
    Eigen::Vector3d G_v;     // global velocity
    Eigen::Matrix3d G_R;     // global rotation
    Eigen::Vector3d acc_bias;  // acceleration bias
    Eigen::Vector3d gyro_bias; // gyroscope bias

    // Covariance.
    Eigen::Matrix<double, 15, 15> cov;
};

class ImuLaserFusion {
  public:
    ImuLaserFusion();

    //bool Update();
    bool SetInitPose(const Eigen::Matrix4f& init_pose);
    bool ProcessImu(const IMUData& imu);
    bool ProcessOdom(const PoseData& pose_data);

    Eigen::Matrix4f GetPose();

  private:
    Eigen::Matrix3d GetSkewMatrix(const Eigen::Vector3d& v);

  private:

    double acc_noise_, gyro_noise_, acc_bias_noise_, gyro_bias_noise_;
    double laser_pose_noise_, laser_orient_noise_;

    Eigen::Vector3d gravity_ = Eigen::Vector3d(0., 0., -9.81007);

    bool initialized_ = false;

    bool has_last_imu_ = false;
    IMUData last_imu_;

    State state_;
};
}

#endif