/*
 * @Description: imu+laser kalman filter
 * @Author: abao
 * @Date: 2020-11-14
 */
#include <ros/ros.h>
#include "glog/logging.h"

#include "lidar_localization/global_defination/global_defination.h"
#include "lidar_localization/mapping/fusion/imu_laser_fusion_flow.hpp"

using namespace lidar_localization;

int main(int argc, char *argv[]) {
    google::InitGoogleLogging(argv[0]);
    FLAGS_log_dir = WORK_SPACE_PATH + "/Log";
    FLAGS_alsologtostderr = 1;

    ros::init(argc, argv, "imu_laser_fusion_node");
    ros::NodeHandle nh;

    std::string imu_topic, odom_topic;
    nh.param<std::string>("imu_topic", imu_topic, "/kitti/oxts/imu");
    //nh.param<std::string>("odom_topic", odom_topic, "/transformed_odom");
    nh.param<std::string>("odom_topic", odom_topic, "/laser_odom");

    std::shared_ptr<ImuLaserFusionFlow> imu_laser_fusion_flow_ptr = std::make_shared<ImuLaserFusionFlow>(nh, imu_topic, odom_topic);

    ros::Rate rate(100);
    while (ros::ok()) {
        ros::spinOnce();

        imu_laser_fusion_flow_ptr->Run();

        rate.sleep();
    }

    return 0;
}