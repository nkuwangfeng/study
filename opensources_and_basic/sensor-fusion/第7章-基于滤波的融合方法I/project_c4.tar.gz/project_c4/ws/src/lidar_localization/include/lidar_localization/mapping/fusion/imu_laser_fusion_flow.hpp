/*
 * @Description: imu laser fusion 任务管理， 放在类里使代码更清晰
 * @Author: abao
 * @Date: 2020-11-14
 */
#ifndef LIDAR_LOCALIZATION_MAPPING_FUSION_IMU_LASER_FUSION_FLOW_HPP_
#define LIDAR_LOCALIZATION_MAPPING_FUSION_IMU_LASER_FUSION_FLOW_HPP_

#include <ros/ros.h>

#include "lidar_localization/subscriber/imu_subscriber.hpp"
#include "lidar_localization/subscriber/odometry_subscriber.hpp"
#include "lidar_localization/publisher/odometry_publisher.hpp"
#include "lidar_localization/mapping/fusion/imu_laser_fusion.hpp"

namespace lidar_localization {

class ImuLaserFusionFlow {
  public:
    ImuLaserFusionFlow(ros::NodeHandle& nh, std::string imu_topic, std::string odom_topic);

    bool Run();

  private:
    bool ReadData();
    bool HasData();
    bool ValidData();
    bool UpdateImuAndOdometry();
    bool PublishData();
    bool DropData();
    bool WaitAndSetInitPose();

  private:
    std::shared_ptr<IMUSubscriber> imu_sub_ptr_;
    std::shared_ptr<OdometrySubscriber> laser_odom_sub_ptr_;
    std::shared_ptr<OdometrySubscriber> gnss_pose_sub_ptr_;
    std::shared_ptr<OdometryPublisher> fused_imu_pub_ptr_;
    std::shared_ptr<OdometryPublisher> fused_odom_pub_ptr_;
    std::shared_ptr<OdometryPublisher> raw_laser_odom_pub_ptr_;

    std::deque<IMUData> imu_data_buf_;
    std::deque<PoseData> laser_odom_data_buff_;
    std::deque<PoseData> gnss_pose_data_buff_;

    std::shared_ptr<ImuLaserFusion> imu_laser_fusion_ptr_;

    bool odometry_inited_ = false;
    Eigen::Matrix4f odom_init_pose_ = Eigen::Matrix4f::Identity();

    Eigen::Matrix4f laser_odometry_ = Eigen::Matrix4f::Identity();
};
}

#endif
