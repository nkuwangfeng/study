/*
 * @Description: 前端里程计算法
 * @Author: Ren Qian
 * @Date: 2020-02-04 18:53:06
 */
#include "lidar_localization/matching/matching.hpp"

#include <pcl/common/transforms.h>
#include <pcl/io/pcd_io.h>
#include "glog/logging.h"

#include "lidar_localization/global_defination/global_defination.h"
#include "lidar_localization/models/registration/ndt_registration.hpp"
#include "lidar_localization/models/cloud_filter/voxel_filter.hpp"
#include "lidar_localization/models/cloud_filter/no_filter.hpp"

namespace lidar_localization {
Matching::Matching()
    :local_map_ptr_(new CloudData::CLOUD()),
     global_map_ptr_(new CloudData::CLOUD()),
     current_scan_ptr_(new CloudData::CLOUD()) {
    
    InitWithConfig();

    InitGlobalMap();

    ResetLocalMap(0.0, 0.0, 0.0);
}

bool Matching::InitWithConfig() {
    std::string config_file_path = WORK_SPACE_PATH + "/config/matching/matching.yaml";
    YAML::Node config_node = YAML::LoadFile(config_file_path);

    std::cout << "-----------------地图定位初始化-------------------" << std::endl;
    InitDataPath(config_node);
    InitRegistration(registration_ptr_, config_node);
    InitFilter("global_map", global_map_filter_ptr_, config_node);
    InitFilter("local_map", local_map_filter_ptr_, config_node);
    InitFilter("frame", frame_filter_ptr_, config_node);
    InitBoxFilter(config_node);
    InitKeyFrames(config_node);

    return true;
}

bool Matching::InitDataPath(const YAML::Node& config_node) {
    map_path_ = config_node["map_path"].as<std::string>();
    return true;
}

bool Matching::InitRegistration(std::shared_ptr<RegistrationInterface>& registration_ptr, const YAML::Node& config_node) {
    std::string registration_method = config_node["registration_method"].as<std::string>();
    std::cout << "地图匹配选择的点云匹配方式为：" << registration_method << std::endl;

    if (registration_method == "NDT") {
        registration_ptr = std::make_shared<NDTRegistration>(config_node[registration_method]);
        global_registration_ptr_ = std::make_shared<NDTRegistration>(config_node[registration_method]);
    } else {
        LOG(ERROR) << "没找到与 " << registration_method << " 相对应的点云匹配方式!";
        return false;
    }

    return true;
}

bool Matching::InitFilter(std::string filter_user, std::shared_ptr<CloudFilterInterface>& filter_ptr, const YAML::Node& config_node) {
    std::string filter_mothod = config_node[filter_user + "_filter"].as<std::string>();
    std::cout << "地图匹配" << filter_user << "选择的滤波方法为：" << filter_mothod << std::endl;

    if (filter_mothod == "voxel_filter") {
        filter_ptr = std::make_shared<VoxelFilter>(config_node[filter_mothod][filter_user]);
    } else if (filter_mothod == "no_filter") {
        filter_ptr = std::make_shared<NoFilter>();
    } else {
        LOG(ERROR) << "没有为 " << filter_user << " 找到与 " << filter_mothod << " 相对应的滤波方法!";
        return false;
    }

    return true;
}

bool Matching::InitBoxFilter(const YAML::Node& config_node) {
    box_filter_ptr_ = std::make_shared<BoxFilter>(config_node);
    return true;
}

bool Matching::InitGlobalMap() {
    pcl::io::loadPCDFile(map_path_, *global_map_ptr_);
    LOG(INFO) << "load global map size:" << global_map_ptr_->points.size();

    local_map_filter_ptr_->Filter(global_map_ptr_, global_map_ptr_);
    LOG(INFO) << "filtered global map size:" << global_map_ptr_->points.size();

    has_new_global_map_ = true;

    return true;
}

bool Matching::ResetLocalMap(float x, float y, float z) {
    std::vector<float> origin = {x, y, z};
    box_filter_ptr_->SetOrigin(origin);
    box_filter_ptr_->Filter(global_map_ptr_, local_map_ptr_);

    registration_ptr_->SetInputTarget(local_map_ptr_);

    has_new_local_map_ = true;

    std::vector<float> edge = box_filter_ptr_->GetEdge();
    LOG(INFO) << "new local map:" << edge.at(0) << ","
                                  << edge.at(1) << ","
                                  << edge.at(2) << ","
                                  << edge.at(3) << ","
                                  << edge.at(4) << ","
                                  << edge.at(5) << std::endl << std::endl;

    return true;
}

bool Matching::InitKeyFrames(const YAML::Node& config_node) {
    std::string key_frames_path = config_node["slam_data"].as<std::string>() + "/key_frames";
    int count = 0;
    for (int i = 0; ; ++i) {
        CloudData::CLOUD_PTR cloud_ptr(new CloudData::CLOUD());
        std::string file_path = key_frames_path + "/key_frame_" + std::to_string(i) + ".pcd";
        LOG(INFO) << "load kf=" << i;
        if (pcl::io::loadPCDFile(file_path, *cloud_ptr) == -1) {
            LOG(INFO) << "finish";
            break;
        }
        sc_manager_.makeAndSaveScancontextAndKeys(*cloud_ptr);
        count++;
    }

    std::string optimized_pose_path = config_node["slam_data"].as<std::string>() + "/trajectory/optimized.txt";
    std::ifstream input(optimized_pose_path);
    if (input.is_open()) {
        Eigen::Matrix4f pose = Eigen::Matrix4f::Identity();
        for (int idx = 0; idx < count; ++idx) {
            for (int i = 0; i < 3; ++i) {
                for (int j = 0; j < 4; ++j) {
                    input >> pose(i, j);
                }
            }
            optimized_pose_.push_back(pose);
        }
        input.close();
    }
    LOG(INFO) << "optimized_pose.size()=" << optimized_pose_.size();
    LOG(INFO) << "op[0]=" << std::endl << optimized_pose_[0] << std::endl;
    LOG(INFO) << "op[1]=" << std::endl << optimized_pose_[1] << std::endl;
}

bool Matching::Update(const CloudData& cloud_data, Eigen::Matrix4f& cloud_pose) {
    std::vector<int> indices;
    pcl::removeNaNFromPointCloud(*cloud_data.cloud_ptr, *cloud_data.cloud_ptr, indices);

    CloudData::CLOUD_PTR filtered_cloud_ptr(new CloudData::CLOUD());
    frame_filter_ptr_->Filter(cloud_data.cloud_ptr, filtered_cloud_ptr);

    static Eigen::Matrix4f step_pose = Eigen::Matrix4f::Identity();
    static Eigen::Matrix4f last_pose = init_pose_;
    static Eigen::Matrix4f predict_pose = init_pose_;

    if (!has_inited_) {
        //predict_pose = current_gnss_pose_;
        LOG(INFO) << "not inited";
        static int esti_count = 0;
        if (EstimatePose(cloud_data, predict_pose)) {
            if (esti_count == 0)
                SetInitPose(predict_pose);
            if (++esti_count > 1)
                has_inited_ = true;
        }
    }

    // 与地图匹配
    CloudData::CLOUD_PTR result_cloud_ptr(new CloudData::CLOUD());
    registration_ptr_->ScanMatch(filtered_cloud_ptr, predict_pose, result_cloud_ptr, cloud_pose);
    pcl::transformPointCloud(*cloud_data.cloud_ptr, *current_scan_ptr_, cloud_pose);

    // 更新相邻两帧的相对运动
    step_pose = last_pose.inverse() * cloud_pose;
    predict_pose = cloud_pose * step_pose;
    last_pose = cloud_pose;

    // 匹配之后判断是否需要更新局部地图
    std::vector<float> edge = box_filter_ptr_->GetEdge();
    for (int i = 0; i < 3; i++) {
        if (fabs(cloud_pose(i, 3) - edge.at(2 * i)) > 50.0 &&
            fabs(cloud_pose(i, 3) - edge.at(2 * i + 1)) > 50.0)
            continue;
        ResetLocalMap(cloud_pose(0,3), cloud_pose(1,3), cloud_pose(2,3));
        break;
    }

    return true;
}

bool Matching::SetGNSSPose(const Eigen::Matrix4f& gnss_pose) {
    LOG(INFO) << "SetGNSSPose";
    current_gnss_pose_ = gnss_pose;

    static int gnss_cnt = 0;
    if (gnss_cnt == 0) {
        SetInitPose(gnss_pose);
    } else if (gnss_cnt > 3) {
        has_inited_ = true;
    }
    gnss_cnt ++;
    return true;
}

bool Matching::EstimatePose(const CloudData& cloud_data, Eigen::Matrix4f& cloud_pose) {
    LOG(INFO) << "EstimatePose";
#if 0
    pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
    kdtree.setInputCloud (global_map_ptr_);
    pcl::PointXYZ searchPoint(x_,y_,z_);
    float radius = 120.f;
    std::vector<int> pointIdxRadiusSearch;
    std::vector<float> pointRadiusSquaredDistance;
    kdtree.radiusSearch (searchPoint, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_cluster (new pcl::PointCloud<pcl::PointXYZ>);
    for (size_t i = 0; i < pointIdxRadiusSearch.size (); ++i)
        cloud_cluster->points.push_back(global_map_ptr_->points[ pointIdxRadiusSearch[i] ]);

    //global_registration_ptr_->SetInputTarget(cloud_cluster);
#endif

#if 0
    global_registration_ptr_->SetInputTarget(local_map_ptr_);

    CloudData::CLOUD_PTR filtered_cloud_ptr(new CloudData::CLOUD());
    frame_filter_ptr_->Filter(cloud_data.cloud_ptr, filtered_cloud_ptr);

    Eigen::Affine3f pc_transform = Eigen::Affine3f::Identity();
    pc_transform.translation()[0] = x_;
    pc_transform.translation()[1] = y_;
    pc_transform.translation()[2] = z_;
    float min_fitness = 100.f;
    Eigen::Matrix4f min_fitness_pose;
    for (int i = 0; i < 36; ++i) {
        pc_transform.rotate (Eigen::AngleAxisf (3.1415f*10.f/180.f, Eigen::Vector3f::UnitZ()));
        CloudData::CLOUD_PTR result_cloud_ptr(new CloudData::CLOUD());
        Eigen::Matrix4f pose;
        global_registration_ptr_->ScanMatch(filtered_cloud_ptr, pc_transform.matrix(), result_cloud_ptr, pose);
        float fitness = global_registration_ptr_->GetFitnessScore();
        LOG(INFO) << "fitness[" << i << "]=" << fitness;
        if (fitness < min_fitness) {
            min_fitness = fitness;
            min_fitness_pose = pose;
        }
    }
    cloud_pose = min_fitness_pose;
    LOG(INFO) << "cloud_pose=" << cloud_pose;
    return true;
#endif

    sc_manager_.makeAndSaveScancontextAndKeys(*cloud_data.cloud_ptr);
    auto detectResult = sc_manager_.detectLoopClosureID();
    int key_frame_index = detectResult.first;
    if (key_frame_index != -1) {
        LOG(INFO) << "scan context find " << key_frame_index;
        // method 1: use theta in optimized_pose_
        //cloud_pose = optimized_pose_[key_frame_index]; // this may be ok

        // method 2: calc theta from continuous pose
        Eigen::Matrix4f curr_pose = optimized_pose_[key_frame_index];
        Eigen::Matrix4f next_pose = optimized_pose_[key_frame_index + 1];
        Eigen::Affine3f transform = Eigen::Affine3f::Identity();
        transform.translation()[0] = curr_pose(0,3);
        transform.translation()[1] = curr_pose(1,3);
        transform.translation()[2] = curr_pose(2,3);
        float theta = atan2(next_pose(1,3)-curr_pose(1,3), next_pose(0,3)-curr_pose(0,3));
        transform.rotate(Eigen::AngleAxisf(theta, Eigen::Vector3f::UnitZ()));
        cloud_pose = transform.matrix();
        return true;
    }

    return false;
}

bool Matching::SetInitPose(const Eigen::Matrix4f& init_pose) {
    init_pose_ = init_pose;
    ResetLocalMap(init_pose(0,3), init_pose(1,3), init_pose(2,3));

    return true;
}

void Matching::GetGlobalMap(CloudData::CLOUD_PTR& global_map) {
    global_map_filter_ptr_->Filter(global_map_ptr_, global_map);
    has_new_global_map_ = false;
}

CloudData::CLOUD_PTR& Matching::GetLocalMap() {
    return local_map_ptr_;
}

CloudData::CLOUD_PTR& Matching::GetCurrentScan() {
    return current_scan_ptr_;
}

bool Matching::HasInited() {
    return has_inited_;
}

bool Matching::HasNewGlobalMap() {
    return has_new_global_map_;
}

bool Matching::HasNewLocalMap() {
    return has_new_local_map_;
}
}