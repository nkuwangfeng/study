# -*- coding: utf-8 -*-
# Filename: demo_abao.py

"""
Test Sim with Allan analysis.
Created on 2018-01-23
@author: dongxiaoguang
"""

import os
import math
import numpy as np
from gnss_ins_sim.sim import imu_model
from gnss_ins_sim.sim import ins_sim

# globals
D2R = math.pi/180

motion_def_path = os.path.abspath('.//demo_motion_def_files//')
fs = 100.0          # IMU sample frequency
gps_fs = 10.0

def test_allan():
    '''
    An imu-gps demo for Sim.
    '''
    #### Customized IMU model parameters, typical for IMU381
    imu_err = {'gyro_b': np.array([0.0, 0.0, 0.0]),
               'gyro_arw': np.array([0.25, 0.25, 0.25]) * 1.0,
               'gyro_b_stability': np.array([3.5, 3.5, 3.5]) * 1.0,
               'gyro_b_corr': np.array([100.0, 100.0, 100.0]),
               'accel_b': np.array([0.0e-3, 0.0e-3, 0.0e-3]),
               'accel_vrw': np.array([0.03119, 0.03009, 0.04779]) * 1.0,
               'accel_b_stability': np.array([4.29e-5, 5.72e-5, 8.02e-5]) * 1.0,
               'accel_b_corr': np.array([200.0, 200.0, 200.0]),
               'mag_std': np.array([0.2, 0.2, 0.2]) * 1.0
              }
    # do not generate GPS and magnetometer data
    imu = imu_model.IMU(accuracy='high-accuracy', axis=6, gps=True)

    #### start simulation
    sim = ins_sim.Sim([fs, gps_fs, 0.0],
                      motion_def_path+"//motion_def_c4_gps.csv",
                      ref_frame=0,
                      imu=imu,
                      mode=None,
                      env=None,
                      algorithm=None)
    sim.run()
    # generate simulation results, summary, and save data to files
    sim.results('')  # save data files
    # plot data
    #sim.plot(['ad_accel', 'ad_gyro'])
    sim.plot(['ref_pos'], opt={'ref_pos': '3d'})

if __name__ == '__main__':
    test_allan()
