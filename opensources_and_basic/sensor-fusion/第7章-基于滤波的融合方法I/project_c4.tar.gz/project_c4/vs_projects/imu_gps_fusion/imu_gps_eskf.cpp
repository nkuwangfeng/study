/*
* @Description: imu gps kalman filter
* @Author: abao
* @Date: 2020-11-22
*/
#include "imu_gps_eskf.h"

#include <iostream>
#include <fstream>
#define _USE_MATH_DEFINES
#include <math.h>

#include <Eigen/Dense>
#include <Eigen/Sparse>

constexpr double kDegreeToRadian = M_PI / 180.;
constexpr double kRadianToDegree = 180. / M_PI;

ImuGpsEskf::ImuGpsEskf() {
	acc_noise_ = 1e-2;
	gyro_noise_ = 1e-4;
	acc_bias_noise_ = 1e-6;
	gyro_bias_noise_ = 1e-8;
	gps_pose_noise_ = 0.1;
	gps_velocity_noise_ = 1;
}

bool ImuGpsEskf::SetInitPose(const Eigen::Matrix4f& init_pose) {
	initialized_ = true;
	// set global P/v/R
	state_.G_P = Eigen::Vector3d(init_pose(0, 3), init_pose(1, 3), init_pose(2, 3));
	state_.G_v.setZero();
	state_.G_R = init_pose.block<3, 3>(0, 0).cast<double>();
	// set bias
	state_.acc_bias.setZero();
	state_.gyro_bias.setZero();

	// Set covariance.
	state_.cov.setZero();
	state_.cov.block<3, 3>(0, 0) = 100. * Eigen::Matrix3d::Identity(); // position std: 10 m
	state_.cov.block<3, 3>(3, 3) = 100. * Eigen::Matrix3d::Identity(); // velocity std: 10 m/s
																		// roll pitch std 10 degree.
	state_.cov.block<2, 2>(6, 6) = 10. * kDegreeToRadian * 10. * kDegreeToRadian * Eigen::Matrix2d::Identity();
	state_.cov(8, 8) = 100. * kDegreeToRadian * 100. * kDegreeToRadian; // yaw std: 100 degree.
																		// Acc bias.
	state_.cov.block<3, 3>(9, 9) = 0.0004 * Eigen::Matrix3d::Identity();
	// Gyro bias.
	state_.cov.block<3, 3>(12, 12) = 0.0004 * Eigen::Matrix3d::Identity();
	return true;
}

static Eigen::Vector3d last_accel_ = Eigen::Vector3d::Zero();

bool ImuGpsEskf::ProcessImu(const imu_t& imu) {
	if (!initialized_)
		return false;

	if (!has_last_imu_) {
		has_last_imu_ = true;
		last_imu_ = imu;
		return false;
	}

	const double delta_t = imu.time - last_imu_.time;
	const double delta_t2 = delta_t * delta_t;

	State last_state = state_;

	// Acc and gyro.
	const Eigen::Vector3d last_acc = Eigen::Vector3d(last_imu_.ax, last_imu_.ay, last_imu_.az);
	const Eigen::Vector3d curr_acc = Eigen::Vector3d(imu.ax, imu.ay, imu.az);
	const Eigen::Vector3d last_gyro = Eigen::Vector3d(last_imu_.gx, last_imu_.gy, last_imu_.gz);
	const Eigen::Vector3d curr_gyro = Eigen::Vector3d(imu.gx, imu.gy, imu.gz);
	const Eigen::Vector3d acc_unbias = 0.5 * (last_acc + curr_acc) - last_state.acc_bias;
	const Eigen::Vector3d gyro_unbias = 0.5 * (last_gyro + curr_gyro) - last_state.gyro_bias;

	// Normal state
	state_.G_P = last_state.G_P + last_state.G_v * delta_t +
		0.5 * (last_state.G_R * acc_unbias + gravity_) * delta_t2;
	state_.G_v = last_state.G_v + (last_state.G_R * acc_unbias + gravity_) * delta_t;
	const Eigen::Vector3d delta_angle_axis = gyro_unbias * delta_t;
	if (delta_angle_axis.norm() > 1e-12) {
		state_.G_R = last_state.G_R * Eigen::AngleAxisd(delta_angle_axis.norm(), delta_angle_axis.normalized()).toRotationMatrix();
	}

#if 0
	Eigen::Matrix3d PHI_x;
	PHI_x << 0, -imu.gz, imu.gy,
		imu.gz, 0, -imu.gx,
		-imu.gy, imu.gx, 0;
	PHI_x = PHI_x * delta_t;
	double phi = std::sqrt(std::pow(imu.gx, 2) + std::pow(imu.gy, 2) + std::pow(imu.gz, 2)) * delta_t;
	Eigen::Matrix3d last_G_R = state_.G_R;
	state_.G_R = state_.G_R * (Eigen::Matrix3d::Identity() + (std::sin(phi) / phi) * PHI_x - ((1 - std::cos(phi)) / std::pow(phi, 2)) * PHI_x * PHI_x);

	Eigen::Vector3d acc_l(imu.ax, imu.ay, imu.az);
	Eigen::Vector3d acc_g = state_.G_R * acc_l;
	Eigen::Vector3d new_velocity = state_.G_v + delta_t * (0.5*(last_G_R*last_accel_ + state_.G_R*acc_l) + gravity_);
	state_.G_P = state_.G_P + 0.5* delta_t *(state_.G_v + new_velocity);
	state_.G_v = new_velocity;
	last_accel_ = acc_l;
#endif

	// \dot X = F_tX + B_tW

	// F_{k-1} = I + F_tT
	const double omega = 7.292115e-5;
	const double L = 32 * kDegreeToRadian;
	Eigen::Matrix<double, 15, 15> Ft = Eigen::Matrix<double, 15, 15>::Zero();
	Ft.block<3, 3>(0, 3) = Eigen::Matrix3d::Identity();
	Ft.block<3, 3>(3, 6) = -state_.G_R * GetSkewMatrix(acc_unbias); // F23
	Ft(6, 7) = omega * sin(L);  // F33
	Ft(6, 8) = -omega * cos(L);
	Ft(7, 6) = -omega * sin(L);
	Ft(8, 6) = omega * cos(L);
	Ft.block<3, 3>(3, 12) = state_.G_R;
	Ft.block<3, 3>(6, 9) = -state_.G_R;
	Eigen::Matrix<double, 15, 15> Fk_1 = Eigen::Matrix<double, 15, 15>::Identity() + Ft * delta_t;

	// B_{k-1} = B_tT
	Eigen::Matrix<double, 15, 6> Bt = Eigen::Matrix<double, 15, 6>::Zero();
	Bt.block<3, 3>(3, 3) = state_.G_R;
	Bt.block<3, 3>(6, 0) = -state_.G_R;
	Eigen::Matrix<double, 15, 6> Bk_1 = Bt * delta_t;

	Eigen::Matrix<double, 6, 6> Qk = Eigen::Matrix<double, 6, 6>::Zero();
	Qk.block<3, 3>(0, 0) = delta_t2 * gyro_noise_ * Eigen::Matrix3d::Identity();
	Qk.block<3, 3>(3, 3) = delta_t2 * acc_noise_ * Eigen::Matrix3d::Identity();

	// update P
	state_.cov = Fk_1 * last_state.cov * Fk_1.transpose() + Bk_1 * Qk * Bk_1.transpose();

	last_imu_ = imu;
	return true;
}

bool ImuGpsEskf::ProcessGps(const gps_t& gps) {
	// observation
	// Yk = [dPx, dPy, dPz, dVx, dVy, dVz]
	Eigen::Matrix<double, 6, 1> Yk;
	Yk.block<3, 1>(0, 0) = Eigen::Vector3d(gps.px, gps.py, gps.pz) - state_.G_P;
	Yk.block<3, 1>(3, 0) = Eigen::Vector3d(gps.vx, gps.vy, gps.vz) - state_.G_v;

	// K_k = P_kG_k^T(G_kP_kG_k^T + C_KR_kC_k^T)^{-1}
	const Eigen::MatrixXd& Pk = state_.cov;
	Eigen::Matrix<double, 6, 15> Gk = Eigen::Matrix<double, 6, 15>::Zero();
	Gk.block<3, 3>(0, 0) = Gk.block<3, 3>(3, 3) = Eigen::Matrix3d::Identity();
	Eigen::Matrix<double, 6, 6> Ck = Eigen::Matrix<double, 6, 6>::Identity();
	Eigen::Matrix<double, 6, 6> Rk = Eigen::Matrix<double, 6, 6>::Identity();
	Rk.block<3, 3>(0, 0) *= gps_pose_noise_;
	Rk.block<3, 3>(3, 3) *= gps_velocity_noise_;
	const Eigen::MatrixXd Kk = Pk * Gk.transpose() * (Gk * Pk * Gk.transpose() + Ck * Rk * Ck.transpose()).inverse();

	// \hat{P_k} = (I-K_kG_k)\check{P_k}
	state_.cov = (Eigen::Matrix<double, 15, 15>::Identity() - Kk * Gk) * Pk;

	// \hat{x_k} = \check{x_k} + K_k(Y_k-G_k\check{X_k})
	Eigen::Matrix<double, 15, 1> Xk = Eigen::Matrix<double, 15, 1>::Zero();
	const Eigen::VectorXd delta_x = Kk * (Yk - Gk*Xk);

	// \hat{x_k} = \check{x_k} + delta_x
	state_.G_P += delta_x.block<3, 1>(0, 0);
	state_.G_v += delta_x.block<3, 1>(3, 0);
	state_.acc_bias += delta_x.block<3, 1>(9, 0);
	state_.gyro_bias += delta_x.block<3, 1>(12, 0);
	if (delta_x.block<3, 1>(6, 0).norm() > 1e-12) {
		state_.G_R *= Eigen::AngleAxisd(delta_x.block<3, 1>(6, 0).norm(), delta_x.block<3, 1>(6, 0).normalized()).toRotationMatrix();
	}

	return true;
}

Eigen::Matrix4f ImuGpsEskf::GetPose() {
	Eigen::Matrix4f pose;
	pose.block<3, 3>(0, 0) = state_.G_R.cast<float>();
	pose(0, 3) = state_.G_P(0);
	pose(1, 3) = state_.G_P(1);
	pose(2, 3) = state_.G_P(2);
	return pose;
}

Eigen::Matrix3d ImuGpsEskf::GetSkewMatrix(const Eigen::Vector3d& v) {
	Eigen::Matrix3d w;
	w << 0., -v(2), v(1),
		v(2), 0., -v(0),
		-v(1), v(0), 0.;

	return w;
}
