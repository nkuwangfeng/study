/*
* @Description: imu laser kalman filter
* @Author: abao
* @Date: 2020-11-22
*/
#ifndef IMU_GPS_ESKF_HPP_
#define IMU_GPS_ESKF_HPP_

#include <Eigen/Dense>

typedef struct {
	Eigen::Vector3d G_P;     // global pose
	Eigen::Vector3d G_v;     // global velocity
	Eigen::Matrix3d G_R;     // global rotation
	Eigen::Vector3d acc_bias;  // acceleration bias
	Eigen::Vector3d gyro_bias; // gyroscope bias

								// Covariance.
	Eigen::Matrix<double, 15, 15> cov;
} State;

typedef struct {
	double time;
	double ax, ay, az;
	double gx, gy, gz;
} imu_t;

typedef struct {
	double time;
	double px, py, pz;
	double vx, vy, vz;
} gps_t;

class ImuGpsEskf {
public:
	ImuGpsEskf();

	bool SetInitPose(const Eigen::Matrix4f& init_pose);
	bool ProcessImu(const imu_t& imu);
	bool ProcessGps(const gps_t& gps);

	Eigen::Matrix4f GetPose();

private:
	Eigen::Matrix3d GetSkewMatrix(const Eigen::Vector3d& v);

private:

	double acc_noise_, gyro_noise_, acc_bias_noise_, gyro_bias_noise_;
	double gps_pose_noise_, gps_velocity_noise_;

	Eigen::Vector3d gravity_ = Eigen::Vector3d(0., 0., -9.8);

	bool initialized_ = false;

	bool has_last_imu_ = false;
	imu_t last_imu_;

	State state_;
};

#endif