#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#define _USE_MATH_DEFINES
#include <math.h>

#include <Eigen/Dense>
#include <Eigen/Sparse>

#include "LocalCartesian.hpp"
#include "imu_gps_eskf.h"

using namespace Eigen;

constexpr double kDegreeToRadian = M_PI / 180.;
constexpr double kRadianToDegree = 180. / M_PI;
constexpr char separator = ',';

typedef struct {
	double x, y, z;
} accel_t, gyro_t, pose_t, lla_t;

typedef struct {
	double d[6];
} raw_gps_t;

std::vector<double> load_double(const std::string& filename) {
	std::vector<double> result;
	std::ifstream input(filename, std::ifstream::in);
	std::string line;
	if (input.is_open()) {
		std::getline(input, line);
		while (std::getline(input, line)) {
			double d = ::atof(line.c_str());
			result.push_back(d);
		}
		input.close();
	}
	return result;
}

template<typename T>
std::vector<T> load_xyz(const std::string& filename) {
	std::vector<T> xyzs;
	std::ifstream input(filename, std::ifstream::in);
	std::string line;
	if (input.is_open()) {
		std::getline(input, line);
		while (std::getline(input, line)) {
			std::stringstream liness(line);
			std::string x, y, z;
			std::getline(liness, x, separator);
			std::getline(liness, y, separator);
			std::getline(liness, z);
			T xyz;
			xyz.x = ::atof(x.c_str());
			xyz.y = ::atof(y.c_str());
			xyz.z = ::atof(z.c_str());
			xyzs.push_back(xyz);
		}
		input.close();
	}
	return xyzs;
}

template<typename T>
std::vector<T> load_6d(const std::string& filename) {
	std::vector<T> result;
	std::ifstream input(filename, std::ifstream::in);
	std::string line;
	if (input.is_open()) {
		std::getline(input, line);
		while (std::getline(input, line)) {
			std::stringstream liness(line);
			std::string d[6];
			T t;
			for (int i = 0; i < 6; ++i) {
				std::getline(liness, d[i], separator);
				t.d[i] = ::atof(d[i].c_str());
			}
			result.push_back(t);
		}
		input.close();
	}
	return result;
}

void lla_to_enu(const Eigen::Vector3d& init_lla, const Eigen::Vector3d& lla, Eigen::Vector3d& enu) {
	static GeographicLib::LocalCartesian local_cartesian;
	local_cartesian.Reset(init_lla(0), init_lla(1), init_lla(2));
	local_cartesian.Forward(lla(0), lla(1), lla(2),
		enu.data()[0], enu.data()[1], enu.data()[2]);
}

void save_pose(std::ofstream& ofs, const Eigen::Matrix4f& pose) {
	for (int i = 0; i < 3; ++i) {
		for (int j = 0; j < 4; ++j) {
			ofs << pose(i, j);

			if (i == 2 && j == 3) {
				ofs << std::endl;
			} else {
				ofs << " ";
			}
		}
	}
}

const std::string path = "d:\\VirtualBox\ VMs\\share\\lidar_fusion\\2020-11-22-16-27-31\\";

// lla -> enu
int transfer_enu_ref_pos() {
	std::vector<lla_t> ref_pos = load_xyz<lla_t>(path + "ref_pos.csv");
	std::ofstream output(path + "enu_ref_pos.txt");

	Vector3d init_lla(ref_pos[0].x, ref_pos[0].y, ref_pos[0].z);
	for (const lla_t& lla : ref_pos) {
		Vector3d lla(lla.x, lla.y, lla.z);
		Vector3d enu;
		lla_to_enu(init_lla, lla, enu);
		output << "1 0 0 " << enu(0) << " 0 1 0 " << enu(1) << " 0 0 1 " << enu(2) << std::endl;
	}
	output.close();
	return 0;
}

int imu_positioning() {
	std::vector<double> times = load_double(path + "time.csv");
	//std::vector<accel_t> accels = load_xyz<accel_t>(path + "accel-0.csv");
	//std::vector<gyro_t> gyros = load_xyz<gyro_t>(path + "gyro-0.csv");
	std::vector<accel_t> accels = load_xyz<accel_t>(path + "ref_accel.csv");
	std::vector<gyro_t> gyros = load_xyz<gyro_t>(path + "ref_gyro.csv");
	assert(times.size() == accels.size() && times.size() == gyros.size());
	std::vector<imu_t> imus;
	for (size_t i = 0; i < times.size(); ++i) {
		// Body->RFU
		imu_t imu = { times[i], accels[i].y, accels[i].x, -accels[i].z, gyros[i].y, gyros[i].x, -gyros[i].z };
		imus.push_back(imu);
	}

	ImuGpsEskf eskf;
	eskf.SetInitPose(Matrix4f::Identity());

	std::ofstream output(path + "enu_imu.txt");
	for (const imu_t& imu : imus) {
		eskf.ProcessImu(imu);
		save_pose(output, eskf.GetPose());
	}
	output.close();
	return 0;
}

int imu_gps_fusion() {

	// load imu
	std::vector<double> times = load_double(path + "time.csv");
	std::vector<accel_t> accels = load_xyz<accel_t>(path + "accel-0.csv");
	std::vector<gyro_t> gyros = load_xyz<gyro_t>(path + "gyro-0.csv");
	assert(times.size() == accels.size() && times.size() == gyros.size());
	std::vector<imu_t> imus;
	imus.reserve(times.size());
	for (size_t i = 0; i < times.size(); ++i) {
		// Body->RFU
		imu_t imu = { times[i], accels[i].y, accels[i].x, -accels[i].z, gyros[i].y, gyros[i].x, -gyros[i].z };
		imus.push_back(imu);
	}

	// load gps
	std::vector<double> gps_times = load_double(path + "gps_time.csv");
	std::vector<raw_gps_t> raw_gps = load_6d<raw_gps_t>(path + "gps-0.csv");
	assert(gps_times.size() == raw_gps.size());
	Vector3d init_lla(raw_gps[0].d[0], raw_gps[0].d[1], raw_gps[0].d[2]);
	std::vector<gps_t> gpss;
	gpss.reserve(gps_times.size());
	for (size_t i = 0; i < gps_times.size(); ++i) {
		Vector3d lla(raw_gps[i].d[0], raw_gps[i].d[1], raw_gps[i].d[2]);
		Vector3d enu;
		lla_to_enu(init_lla, lla, enu);
		// P: LLA->ENU, V: NED->ENU
		gps_t gps = { gps_times[i], enu(0), enu(1), enu(2), raw_gps[i].d[4], raw_gps[i].d[3], -raw_gps[i].d[5]};
		gpss.push_back(gps);
	}

	// eskf
	ImuGpsEskf eskf;
	eskf.SetInitPose(Matrix4f::Identity());

	std::ofstream output(path + "enu_imu_gps.txt");
	int imu_index = 0, gps_index = 0;
	while (imu_index < imus.size() || gps_index < gpss.size()) {
		double imu_time = imu_index < imus.size() ? imus[imu_index].time : std::numeric_limits<double>::max();
		double gps_time = gps_index < gpss.size() ? gpss[gps_index].time : std::numeric_limits<double>::max();
		if (imu_time <= gps_time) {
			eskf.ProcessImu(imus[imu_index++]);
			save_pose(output, eskf.GetPose());
		} else {
			eskf.ProcessGps(gpss[gps_index++]);
		}
	}
	output.close();
	return 0;
}

int main() {
	return imu_positioning();
}