#include <iostream>
#include <fstream>
#include <sstream>
#define _USE_MATH_DEFINES
#include <math.h>
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <Eigen/Geometry>

using namespace Eigen;

constexpr double kDegreeToRadian = M_PI / 180.;
constexpr double kRadianToDegree = 180. / M_PI;

constexpr double g = 9.8;
constexpr double omega = 7.292115e-5;
constexpr double L = 60 * kDegreeToRadian;

static int get_max_index(MatrixXd m, int rows) {
	int result = 0;
	for (int i = 1; i < rows; ++i) {
		if (std::abs(m(i)) > std::abs(m(result)))
			result = i;
	}
	return result;
}

Matrix<double, 15, 15> make_F(const Matrix3d& Cbn, double fe, double fn, double fu) {
	Matrix<double, 15, 15> F = Matrix<double, 15, 15>::Zero();
	F.block<3, 3>(0, 3) = Matrix3d::Identity();
	F.block<3, 3>(3, 12) = Cbn;
	F.block<3, 3>(6, 9) = -Cbn;
	F(3, 7) = -fu;
	F(3, 8) = fn;
	F(4, 6) = fu;
	F(4, 8) = -fe;
	F(5, 6) = -fn;
	F(5, 7) = fe;
	F(6, 7) = omega *sin(L);
	F(6, 8) = -omega*cos(L);
	F(7, 6) = -omega*sin(L);
	F(8, 6) = omega*cos(L);
	return F;
}

int analyze_static() {
	Matrix<double, 15, 15> F = make_F(Matrix3d::Identity(), 0, 0, -9.8);
	Matrix<double, 6, 15> G = Matrix<double, 6, 15>::Zero();
	G.block<6, 6>(0, 0) = Matrix<double, 6, 6>::Identity();

	Matrix<double, 6 * 15, 15> Q = Matrix<double, 6 * 15, 15>::Zero();
	for (int i = 0; i < 15; ++i) {
		Q.block<6, 15>(i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(i * 6, 0) *= F;
		}
	}

	JacobiSVD<MatrixXd> svd(Q, ComputeThinU | ComputeThinV);
	MatrixXd U = svd.matrixU();
	MatrixXd V = svd.matrixV();
	MatrixXd sigma = svd.singularValues();

	Matrix<double, 90, 1> Y = Matrix<double, 90, 1>::Ones() * 0.1;

	std::vector<double> sorted_sigma(15, 0.);
	for (int i = 0; i < 15; ++i) {
		MatrixXd Xi = U.col(i).transpose() * Y * V.col(i) / svd.singularValues()(i);
		int max_index = get_max_index(Xi, 15);
		sorted_sigma[max_index] = svd.singularValues()(i);
	}
	std::cout << "static:" << std::endl;
	for (int i = 0; i < 15; ++i) {
		std::cout << "index[" << i << "]=" << sorted_sigma[i] << std::endl;
	}

	return 0;
}

int analyze_const_speed() {
	Matrix<double, 15, 15> F1 = make_F(Matrix3d::Identity(), 0, 0, -9.8);
	Matrix<double, 15, 15> F2 = make_F(Matrix3d::Identity(), 0, 0, -9.8);
	Matrix<double, 6, 15> G = Matrix<double, 6, 15>::Zero();
	G.block<6, 6>(0, 0) = Matrix<double, 6, 6>::Identity();

	Matrix<double, 6 * 15 * 2, 15> Q = Matrix<double, 6 * 15 * 2, 15>::Zero();
	for (int i = 0; i < 15; ++i) {
		Q.block<6, 15>(i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(i * 6, 0) *= F1;
		}
		Q.block<6, 15>(6 * 15 + i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(6 * 15 + i * 6, 0) *= F2;
		}
	}

	JacobiSVD<MatrixXd> svd(Q, ComputeThinU | ComputeThinV);
	MatrixXd U = svd.matrixU();
	MatrixXd V = svd.matrixV();
	MatrixXd sigma = svd.singularValues();

	Matrix<double, 180, 1> Y = Matrix<double, 180, 1>::Ones() * 0.1;

	std::vector<double> sorted_sigma(15, 0.);
	for (int i = 0; i < 15; ++i) {
		MatrixXd Xi = U.col(i).transpose() * Y * V.col(i) / svd.singularValues()(i);
		int max_index = get_max_index(Xi, 15);
		sorted_sigma[max_index] = svd.singularValues()(i);
	}
	std::cout << "analyze_const_speed:" << std::endl;
	for (int i = 0; i < 15; ++i) {
		std::cout << "index[" << i << "]=" << sorted_sigma[i] << std::endl;
	}
	return 0;
}

int analyze_rotation() {
	Matrix<double, 15, 15> F1 = make_F(Matrix3d::Identity(), 0, 0, -9.8);
	Matrix<double, 15, 15> F2 = make_F(Matrix3d::Identity() * AngleAxisd(90 * kDegreeToRadian, Eigen::Vector3d::UnitZ()), 0, 0, -9.8);
	Matrix<double, 6, 15> G = Matrix<double, 6, 15>::Zero();
	G.block<6, 6>(0, 0) = Matrix<double, 6, 6>::Identity();

	Matrix<double, 6 * 15 * 2, 15> Q = Matrix<double, 6 * 15 * 2, 15>::Zero();
	for (int i = 0; i < 15; ++i) {
		Q.block<6, 15>(i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(i * 6, 0) *= F1;
		}
		Q.block<6, 15>(6 * 15 + i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(6 * 15 + i * 6, 0) *= F2;
		}
	}

	JacobiSVD<MatrixXd> svd(Q, ComputeThinU | ComputeThinV);
	MatrixXd U = svd.matrixU();
	MatrixXd V = svd.matrixV();
	MatrixXd sigma = svd.singularValues();

	Matrix<double, 180, 1> Y = Matrix<double, 180, 1>::Ones() * 0.1;

	std::vector<double> sorted_sigma(15, 0.);
	for (int i = 0; i < 15; ++i) {
		MatrixXd Xi = U.col(i).transpose() * Y * V.col(i) / svd.singularValues()(i);
		int max_index = get_max_index(Xi, 15);
		sorted_sigma[max_index] = svd.singularValues()(i);
	}
	std::cout << "rotation:" << std::endl;
	for (int i = 0; i < 15; ++i) {
		std::cout << "index[" << i << "]=" << sorted_sigma[i] << std::endl;
	}
	return 0;
}

int analyze_acceleration_deceleration() {
	Matrix<double, 15, 15> F1 = make_F(Matrix3d::Identity(), 0, 0, -9.8);
	Matrix<double, 15, 15> F2 = make_F(Matrix3d::Identity(), 0, 10, -9.8);
	Matrix<double, 15, 15> F3 = make_F(Matrix3d::Identity(), 0, -10, -9.8);
	Matrix<double, 6, 15> G = Matrix<double, 6, 15>::Zero();
	G.block<6, 6>(0, 0) = Matrix<double, 6, 6>::Identity();

	Matrix<double, 90 * 3, 15> Q = Matrix<double, 90 * 3, 15>::Zero();
	for (int i = 0; i < 15; ++i) {
		Q.block<6, 15>(i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(i * 6, 0) *= F1;
		}
		Q.block<6, 15>(90 + i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(90 + i * 6, 0) *= F2;
		}
		Q.block<6, 15>(180 + i * 6, 0) = G;
		for (int j = 0; j < i; ++j) {
			Q.block<6, 15>(180 + i * 6, 0) *= F3;
		}
	}

	JacobiSVD<MatrixXd> svd(Q, ComputeThinU | ComputeThinV);
	MatrixXd U = svd.matrixU();
	MatrixXd V = svd.matrixV();
	MatrixXd sigma = svd.singularValues();

	Matrix<double, 90*3, 1> Y = Matrix<double, 90*3, 1>::Ones() * 0.1;

	std::vector<double> sorted_sigma(15, 0.);
	for (int i = 0; i < 15; ++i) {
		MatrixXd Xi = U.col(i).transpose() * Y * V.col(i) / svd.singularValues()(i);
		int max_index = get_max_index(Xi, 15);
		sorted_sigma[max_index] = svd.singularValues()(i);
	}
	std::cout << "acceleration/deceleration:" << std::endl;
	for (int i = 0; i < 15; ++i) {
		std::cout << "index[" << i << "]=" << sorted_sigma[i] << std::endl;
	}
	return 0;
}

int main() {
	analyze_static();
	analyze_const_speed();
	analyze_rotation();
	analyze_acceleration_deceleration();
	return 0;
}